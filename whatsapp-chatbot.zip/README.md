# WhatsApp Chatbot

A basic WhatsApp chatbot using whatsapp-web.js and Express.