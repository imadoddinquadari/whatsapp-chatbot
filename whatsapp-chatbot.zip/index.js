const { Client } = require('whatsapp-web.js');
const qrcode = require('qrcode-terminal');
const express = require('express');

const app = express();
const client = new Client();

client.on('qr', (qr) => {
    qrcode.generate(qr, { small: true });
});

client.on('ready', () => {
    console.log('WhatsApp bot is ready!');
});

client.initialize();

app.get('/', (req, res) => {
    res.send('WhatsApp bot is running!');
});

app.listen(3000, () => {
    console.log('Server is running on port 3000');
});